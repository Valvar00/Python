import pickle as pkl
import numpy as np

filename = "x_val_cor"
filename2 = "y_val_cor"

"""
def compose():
    #x_com,y_com= pkl.load(open('train1New.pkl', mode='r+b'))
    #x_ins = x_com[0:20000]
    #print(x_ins,type(x_ins))
    #x_ins = np.array(x_ins)
    #print(x_ins, type(x_ins))
    x_cor, y_cor = pkl.load(open('train_corr.pkl', mode='r+b'))
    y_ins = y_cor[0:5000]
    x_ins = x_cor[0:5000]
    print(y_ins, type(y_ins))
    for i in range(5000):
        x_ins[i] = np.ndarray.round(x_ins[i],1)
    print(x_ins,x_ins.shape)
    pickle_out_x = open(filename, mode="wb")
    pickle_out_y = open(filename2, mode="wb")
    pkl.dump(x_ins, pickle_out_x)
    pkl.dump(y_ins, pickle_out_y)
    pickle_out_x.close()
    pickle_out_y.close()
"""
"""
def check():
    x_com= pkl.load(open(filename, mode='r+b'))
    y_com= pkl.load(open(filename2, mode='r+b'))



    #with gzip.open(filename, 'rb') as f:
    #    x_com = f.read()
    #with gzip.open(filename2, 'rb') as f2:
    #    y_com = f2.read()



    #x_unzip=zlib.decompress(x_com)
    #x_unzip_int= int.from_bytes(x_unzip,"big")
    #x_unzip_nd = np.array(x_unzip_int)
    #y_unzip = zlib.decompress(y_com)
    #y_unzip_int = int.from_bytes(y_unzip,"little")
    #y_unzip_nd = np.array(y_unzip_int)
    #print(type(x_unzip_nd),print(x_unzip_nd))
    #print(type(y_unzip_nd))
    #x_unzip = x_com.reshape(1000,1296)
    #y_unzip = y_com.reshape(1000,1)
"""

def hamming_distance(X, X_train):
    distance_matrix=(1-X)@X_train.transpose()
    distance_matrix+=X@(1-X_train.transpose())
    return distance_matrix

def split(Dist):
    k=3
    idx = []
    for i in range(0,Dist.shape[0]):
        idx.append(np.argpartition(Dist[i],k))
    idx=np.array(idx)
    return idx

def dec_labels_10(NN):
    labels = []
    for i in NN:
        labels.append(i[:5])
    labels=np.array(labels)
    return labels

def transform_to_label(Labels,y_train):
    y_conv=[]
    m_com=[]
    for i in Labels:
        y_conv.append(y_train[i[:5]])
    y_conv = np.array(y_conv)
    y_conv=y_conv.astype(int)
    for k in y_conv:
        counts = np.bincount(k)
        m_com.append(np.argmax(counts))
    m_com=np.array(m_com)
    return(m_com)

def predict(x):
    """
    Function takes images as the argument. They are stored in the matrix X (NxD).
    Function returns a vector y (Nx1), where each element of the vector is a class numer {0, ..., 9} associated with recognized type of cloth.
    :param x: matrix NxD
    :return: vector Nx1
    """
    x_train=pkl.load(open(filename, mode='rb'))
    y_train=pkl.load(open(filename2, mode='rb')).reshape(30000)
    distance = hamming_distance(x, x_train)
    near = split(distance)
    conv_y = dec_labels_10(near)
    prediction = transform_to_label(conv_y, y_train)
    return prediction.reshape(x.shape[0],1)

#Molus za progy